<!DOCTYPE html>
<html lang="es" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Administracion</title>
    <link rel="icon" href="../ico.ico" type="image/x-icon">
    <link type="text/css" rel="stylesheet" href="../css/bootstrap.min.css"  media="screen,projection"/>
    <link rel="stylesheet" href="../css/admin.css" type="text/css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>

<body>
  <form action="panel.php" method="post">
    <label for="user">Usuario</label>
    <input type="text" name="user">
    <label for="password">Usuario</label>
    <input type="password" name="password">
    <button type="submit">Ingresar</button>
  </form>
</body>
